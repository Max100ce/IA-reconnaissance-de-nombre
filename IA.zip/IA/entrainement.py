import numpy as np
from tqdm import *
from random import randint
from math import *

# Ouverture des images et des labels

fichierImage = open('pack/train-images.idx3-ubyte', 'rb')
fichierLabel = open('pack/train-labels.idx1-ubyte', 'rb')
image = np.array(list(fichierImage.read())) / 255
label = np.array(list(fichierLabel.read()))
fichierImage.close()
fichierLabel.close()

image = image[16:].reshape(int(len(image[16:]) / 784), 1, 784)
label = label[8:]

data = []
for i in range(0, len(image)):
	data.append(np.array([image[i], label[i]]))
data = np.array(data)

# Ouvertures des 45 listes de poids bias

liste_poids1_txt_fichier = open('liste-poids1.txt')
liste_poids2_txt_fichier = open('liste-poids2.txt')
liste_poids3_txt_fichier = open('liste-poids3.txt')
liste_bias1_txt_fichier = open('liste-bias1.txt')
liste_bias2_txt_fichier = open('liste-bias2.txt')
liste_bias3_txt_fichier = open('liste-bias3.txt')

liste_poids1_txt = liste_poids1_txt_fichier.read()
liste_poids2_txt = liste_poids2_txt_fichier.read()
liste_poids3_txt = liste_poids3_txt_fichier.read()
liste_bias1_txt = liste_bias1_txt_fichier.read()
liste_bias2_txt = liste_bias2_txt_fichier.read()
liste_bias3_txt = liste_bias3_txt_fichier.read()

liste_poids1 = liste_poids1_txt.split('/')
liste_poids2 = liste_poids2_txt.split('/')
liste_poids3 = liste_poids3_txt.split('/')

for i in range(len(liste_poids1)):
	liste_poids1[i] = liste_poids1[i].split(';')
	for j in range(len(liste_poids1[i])):
		liste_poids1[i][j] = liste_poids1[i][j].split(',')
		for k in range(len(liste_poids1[i][j])):
			liste_poids1[i][j][k] = float(liste_poids1[i][j][k])

for i in range(len(liste_poids2)):
	liste_poids2[i] = liste_poids2[i].split(';')
	for j in range(len(liste_poids2[i])):
		liste_poids2[i][j] = liste_poids2[i][j].split(',')
		for k in range(len(liste_poids2[i][j])):
			liste_poids2[i][j][k] = float(liste_poids2[i][j][k])
			
for i in range(len(liste_poids3)):
	liste_poids3[i] = liste_poids3[i].split(';')
	for j in range(len(liste_poids3[i])):
		liste_poids3[i][j] = liste_poids3[i][j].split(',')
		for k in range(len(liste_poids3[i][j])):
			liste_poids3[i][j][k] = float(liste_poids3[i][j][k])

liste_bias1 = liste_bias1_txt.split('/')
liste_bias2 = liste_bias2_txt.split('/')
liste_bias3 = liste_bias3_txt.split('/')

for i in range(len(liste_bias1)):
	liste_bias1[i] = liste_bias1[i].split(',')
	for j in range(len(liste_bias1[i])):
		liste_bias1[i][j] = float(liste_bias1[i][j])

for i in range(len(liste_bias2)):
	liste_bias2[i] = liste_bias2[i].split(',')
	for j in range(len(liste_bias2[i])):
		liste_bias2[i][j] = float(liste_bias2[i][j])

for i in range(len(liste_bias3)):
	liste_bias3[i] = liste_bias3[i].split(',')
	for j in range(len(liste_bias3[i])):
		liste_bias3[i][j] = float(liste_bias3[i][j])

liste_poids1 = np.array(liste_poids1)
liste_poids2 = np.array(liste_poids2)
liste_poids3 = np.array(liste_poids3)
liste_bias1 = np.array(liste_bias1)
liste_bias2 = np.array(liste_bias2)
liste_bias3 = np.array(liste_bias3)

liste_poids1_txt_fichier.close()
liste_poids2_txt_fichier.close()
liste_poids3_txt_fichier.close()
liste_bias1_txt_fichier.close()
liste_bias2_txt_fichier.close()
liste_bias3_txt_fichier.close()

listeIndexTable = np.array([[0, 1, 2, 3, 4, 5, 6, 7, 8], [0, 9, 10, 11, 12, 13, 14, 15, 16], [1, 9, 17, 18, 19, 20, 21, 22, 23], [2, 10, 17, 24, 25, 26, 27, 28, 29], [3, 11, 18, 24, 30, 31, 32, 33, 34], [4, 12, 19, 25, 30, 35, 36, 37, 38], [5, 13, 20, 26, 31, 35, 39, 40, 41], [6, 14, 21, 27, 32, 36, 39, 42, 43], [7, 15, 22, 28, 33, 37, 40, 42, 44], [8, 16, 23, 29, 34, 38, 41, 43, 44]])
listeTable = np.array([(0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7), (0, 8), (0, 9), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9), (3, 4), (3, 5), (3, 6), (3, 7), (3, 8), (3, 9), (4, 5), (4, 6), (4, 7), (4, 8), (4, 9), (5, 6), (5, 7), (5, 8), (5, 9), (6, 7), (6, 8), (6, 9), (7, 8), (7, 9), (8, 9)])

# fonctions

def creer_gradient():
	global liste_poids1_gradient
	liste_poids1_gradient = np.zeros(liste_poids1.shape)
	global liste_poids2_gradient
	liste_poids2_gradient = np.zeros(liste_poids2.shape)
	global liste_poids3_gradient
	liste_poids3_gradient = np.zeros(liste_poids3.shape)
	global liste_bias1_gradient
	liste_bias1_gradient = np.zeros(liste_bias1.shape)
	global liste_bias2_gradient
	liste_bias2_gradient = np.zeros(liste_bias2.shape)
	global liste_bias3_gradient
	liste_bias3_gradient = np.zeros(liste_bias3.shape)

def afficheImage(image):
	image = image.reshape(28, 28)
	imageChar = ''
	#while np.array_equiv(image[0], np.zeros(image.shape[0])) and np.array_equiv(image[0:][0], np.zeros(image.shape[0])) and np.array_equiv(image[-1], np.zeros(image.shape[0])) and np.array_equiv(image[0:][-1], np.zeros(image.shape[0])):
	#	image = image[1:-2, 1:-2]
	while np.array_equiv(image[0], np.zeros(image.shape[1])):
		image = image[1:]
	while np.array_equiv(image[-1], np.zeros(image.shape[1])):
		image = image[:-2]
	while np.array_equiv(image[0:, 0], np.zeros(image.shape[0])):
		image = image[0:, 1:]
	while np.array_equiv(image[0:, -1], np.zeros(image.shape[0])):
		image = image[0:, :-2]

	while image.shape[1] < image.shape[0]:
		image = np.concatenate((np.array([[0] for i in range(image.shape[0])]), image), axis=1)
		if image.shape[1] < image.shape[0]:
			image = np.concatenate((image, np.array([[0] for i in range(image.shape[0])])), axis=1)

	while image.shape[0] < image.shape[1]:
		image = np.concatenate((np.array([[0 for i in range(image.shape[1])]]), image), axis=0)
		if image.shape[0] < image.shape[1]:
			image = np.concatenate((image, np.array([[0 for i in range(image.shape[1])]])), axis=0)

	imageChar = ''.join([' _' for i in range(image.shape[1] + 2)]) + '\n'
	imageChar += '|' + ''.join(['  ' for i in range(image.shape[1] + 1)]) + ' |\n'
	for i in range(image.shape[0]):
		imageChar += '| '
		for j in range(image.shape[1]):
			imageChar += ' ' + listeChar[floor(image[i, j] * 2.5)]
		imageChar += '  |\n'
	imageChar += '|' + ''.join(['  ' for i in range(image.shape[1] + 1)]) + ' |\n'
	imageChar += ''.join([' ‾' for i in range(image.shape[1] + 2)]) + '\n'
	print(imageChar)

def calculCout(sortie, listeVoulue):
	return np.average(np.square(sortie - listeVoulue))

def trouveListeVoulue(label, i):
	if label <= i:
		return np.array([np.array([1, 0])])
	else:
		return np.array([np.array([0, 1])])

def calculGradientNeuronne(n, autreListe, autreListe2, autreListe3=[]):
	if n == 3:
		return 2 * (autreListe - autreListe2)
	else:
		return np.sum(autreListe / (2 * np.square(np.cosh(autreListe2))) * autreListe3, axis=1)


def calculGradientBias(autreListe, autreListe2):
	return autreListe2 / (2 * np.square(np.cosh(autreListe)))

def calculGradientPoids(n, autreListe, autreListe2, autreListe3):
	if n == 3:
		return np.concatenate([autreListe.reshape(16, 1)] * 2, axis=1) / (2 * np.square(np.cosh(autreListe2))) * autreListe3
	if n == 2:
		return np.concatenate([autreListe.reshape(16, 1)] * 16, axis=1) / (2 * np.square(np.cosh(autreListe2))) * autreListe3
	if n == 1:
		return np.concatenate([autreListe.reshape(784, 1)] * 16, axis=1) / (2 * np.square(np.cosh(autreListe2))) * autreListe3

def save(poids1, poids2, poids3, bias1, bias2, bias3):
	fichier_liste_poids1 = open('liste-poids1.txt', 'w')
	fichier_liste_poids2 = open('liste-poids2.txt', 'w')
	fichier_liste_poids3 = open('liste-poids3.txt', 'w')
	fichier_liste_bias1 = open('liste-bias1.txt', 'w')
	fichier_liste_bias2 = open('liste-bias2.txt', 'w')
	fichier_liste_bias3 = open('liste-bias3.txt', 'w')

	for i in range(45):
		for j in range(784):
			for k in range(16):
				fichier_liste_poids1.write(str(poids1[i][j][k]))
				if k != 15:
					fichier_liste_poids1.write(',')
			if j != 783:
				fichier_liste_poids1.write(';')
		if i != 44:
			fichier_liste_poids1.write('/')

		for j in range(16):
			for k in range(16):
				fichier_liste_poids2.write(str(poids2[i][j][k]))
				if k != 15:
					fichier_liste_poids2.write(',')
			if j != 15:
				fichier_liste_poids2.write(';')
		if i != 44:
			fichier_liste_poids2.write('/')

		for j in range(16):
			for k in range(2):
				fichier_liste_poids3.write(str(poids3[i][j][k]))
				if k != 1:
					fichier_liste_poids3.write(',')
			if j != 15:
				fichier_liste_poids3.write(';')
		if i != 44:
			fichier_liste_poids3.write('/')

		for j in range(16):
			fichier_liste_bias1.write(str(bias1[i][j]))
			if j != 15:
				fichier_liste_bias1.write(',')
		if i != 44:
			fichier_liste_bias1.write('/')

		for j in range(16):
			fichier_liste_bias2.write(str(bias2[i][j]))
			if j != 15:
				fichier_liste_bias2.write(',')
		if i != 44:
			fichier_liste_bias2.write('/')

		for j in range(2):
			fichier_liste_bias3.write(str(bias3[i][j]))
			if j != 1:
				fichier_liste_bias3.write(',')
		if i != 44:
			fichier_liste_bias3.write('/')

	fichier_liste_bias1.close()
	fichier_liste_bias2.close()
	fichier_liste_bias3.close()
	fichier_liste_poids1.close()
	fichier_liste_poids2.close()
	fichier_liste_poids3.close()

coutMoyen = 9.99999
while True:
	creer_gradient()
	description = 'Coût moyen précédent ' + str(round(coutMoyen, 5))
	coutMoyen = 0
	for j in tqdm(range(1000), leave=False, desc=description):
		indexTest = randint(0, len(data) - 1)
		image = data[indexTest][0]
		label = data[indexTest][1]
		#listeChar = ' +■'
		#afficheImage(image)

		for i in range(9):
			indexTable = listeIndexTable[label][i]

			listeNeuronneCache1_avant = image @ liste_poids1[indexTable] + liste_bias1[indexTable]
			listeNeuronneCache1 = np.tanh(listeNeuronneCache1_avant) / 2 + 0.5

			listeNeuronneCache2_avant = listeNeuronneCache1 @ liste_poids2[indexTable] + liste_bias2[indexTable]
			listeNeuronneCache2 = np.tanh(listeNeuronneCache2_avant) / 2 + 0.5

			sortie_avant = listeNeuronneCache2 @ liste_poids3[indexTable] + liste_bias3[indexTable]
			sortie = np.tanh(sortie_avant) / 2 + 0.5

			liste_neuronne_gradient3 = calculGradientNeuronne(3, sortie, trouveListeVoulue(label, i))
			liste_neuronne_gradient2 = calculGradientNeuronne(2, liste_poids3[indexTable], sortie_avant, liste_neuronne_gradient3)
			liste_neuronne_gradient1 = calculGradientNeuronne(1, liste_poids2[indexTable], listeNeuronneCache2_avant, liste_neuronne_gradient2)

			liste_bias3_gradient[indexTable] += calculGradientBias(sortie_avant, liste_neuronne_gradient3)[0]
			liste_bias2_gradient[indexTable] += calculGradientBias(listeNeuronneCache2_avant, liste_neuronne_gradient2)[0]
			liste_bias1_gradient[indexTable] += calculGradientBias(listeNeuronneCache1_avant, liste_neuronne_gradient1)[0]

			liste_poids3_gradient[indexTable] += calculGradientPoids(3, listeNeuronneCache2, sortie_avant, liste_neuronne_gradient3)
			liste_poids2_gradient[indexTable] += calculGradientPoids(2, listeNeuronneCache1, listeNeuronneCache2_avant, liste_neuronne_gradient2)
			liste_poids1_gradient[indexTable] += calculGradientPoids(1, image, listeNeuronneCache1_avant, liste_neuronne_gradient1)

			coutMoyen += calculCout(sortie, trouveListeVoulue(label, i))

	liste_bias3 -= liste_bias3_gradient / 1000
	liste_bias2 -= liste_bias2_gradient / 1000
	liste_bias1 -= liste_bias1_gradient / 1000

	liste_poids3 -= liste_poids3_gradient / 1000
	liste_poids2 -= liste_poids2_gradient / 1000
	liste_poids1 -= liste_poids1_gradient / 1000

	coutMoyen /= 1000

	save(liste_poids1, liste_poids2, liste_poids3, liste_bias1, liste_bias2, liste_bias3)