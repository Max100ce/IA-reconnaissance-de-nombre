from random import random

liste_poids1 = open('liste-poids1.txt', 'w')
liste_poids2 = open('liste-poids2.txt', 'w')
liste_poids3 = open('liste-poids3.txt', 'w')
liste_bias1 = open('liste-bias1.txt', 'w')
liste_bias2 = open('liste-bias2.txt', 'w')
liste_bias3 = open('liste-bias3.txt', 'w')

for i in range(45):
	for j in range(784):
		for k in range(16):
			liste_poids1.write(str(random() * 2 - 1))
			if k != 15:
				liste_poids1.write(',')
		if j != 783:
			liste_poids1.write(';')
	if i != 44:
		liste_poids1.write('/')

	for j in range(16):
		for k in range(16):
			liste_poids2.write(str(random() * 2 - 1))
			if k != 15:
				liste_poids2.write(',')
		if j != 15:
			liste_poids2.write(';')
	if i != 44:
		liste_poids2.write('/')

	for j in range(16):
		for k in range(2):
			liste_poids3.write(str(random() * 2 - 1))
			if k != 1:
				liste_poids3.write(',')
		if j != 15:
			liste_poids3.write(';')
	if i != 44:
		liste_poids3.write('/')

	for j in range(16):
		liste_bias1.write(str(random() * 2 - 1))
		if j != 15:
			liste_bias1.write(',')
	if i != 44:
		liste_bias1.write('/')

	for j in range(16):
		liste_bias2.write(str(random() * 2 - 1))
		if j != 15:
			liste_bias2.write(',')
	if i != 44:
		liste_bias2.write('/')

	for j in range(2):
		liste_bias3.write(str(random() * 2 - 1))
		if j != 1:
			liste_bias3.write(',')
	if i != 44:
		liste_bias3.write('/')

liste_bias1.close()
liste_bias2.close()
liste_bias3.close()
liste_poids1.close()
liste_poids2.close()
liste_poids3.close()